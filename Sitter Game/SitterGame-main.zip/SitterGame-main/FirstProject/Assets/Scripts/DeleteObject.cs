﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeleteObject : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D collider)
    {
        if (collider.name == "CoinStart")
        {
            Destroy(collider.gameObject);
            TimerController.instance.BeginTimer();
        }
        if (collider.name == "CoinEnd")
        {
            Destroy(collider.gameObject);
            TimerController.instance.EndTimer();
        }
    }
}
